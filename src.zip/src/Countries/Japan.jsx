import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

// --- Icons (from react-icons) ---
// Make sure to install: npm install react-icons
import {
  FaPassport, FaMoneyBillWave, FaClock, FaCalendarAlt, FaFileAlt,
  FaBuilding, FaEnvelope, FaPhone, FaCheckCircle, FaExclamationTriangle,
  FaChevronDown, FaStar, FaQuoteLeft, FaPlane, FaHotel, FaUmbrellaBeach,
  FaFileSignature, // Icon for File Processing
  FaCalendarCheck // Icon for Appointment
} from 'react-icons/fa';

// --- Page Data ---
// Data based on official Japan Embassy requirements and your provided updates.

const processingService = {
  title: "Japan Visitor Visa",
  subtitle: "Complete File Processing Service",
  totalFee: "Varies (Contact Agent)", // As per your request
  processingTime: "5-7 Working Days (Post-Submission)", // As per your request
  validity: "Up to 90 Days",
  stay: "Up to 15 or 30 Days",
  category: "Tourist / Business",
  // This is the core service you offer
  serviceIncludes: [
    "Complete Visa File Preparation",
    "Visa Application Form Filling",
    "Detailed Day-by-Day Itinerary (Mandatory)",
    "Confirmed Flight Reservation",
    "Confirmed Hotel Bookings",
    "Travel Insurance (Recommended)"
  ],
  // These are the documents the *client* must provide
  documents: [
    "Original Passport (valid 6+ months) & all old passports",
    "1 Recent Photo (45mm x 45mm, white background)",
    "CNIC Photo Copy (front & back)",
    "Last 6-month Bank Statement (Min. PKR 1,000,000)",
    "Bank Account Maintenance Letter",
    "Family Registration Certificate (FRC)",
    "Employment Letter / Business Documents (NTN, etc.)",
    "Invitation Letter (if business/family visit)"
  ],
  note: "Embassy visa fee is generally gratis (free) for Pakistanis, but agency/VFS service charges apply. Fees are non-refundable."
};

const embassyInfo = {
  title: "Embassy of Japan, Islamabad",
  address: "Plot No. 53-70, Ramna 5/4, Diplomatic Enclave I, Islamabad",
  phone: "+92-51-9072-500",
  email: "ryoji@ib.mofa.go.jp",
  note: "Residents of Punjab, KPK, GB, and AJK must submit their file here in person."
};

const consulateInfo = {
  title: "Consulate-General of Japan, Karachi",
  address: "6/2 Civil Lines, Abdullah Haroon Road, Karachi",
  phone: "+92-21-3522-0800",
  email: "cgjapan3@super.net.pk",
  note: "Residents of Sindh & Balochistan submit applications here, often via VFS Global."
};

// --- Japan-Specific FAQs ---
const faqs = [
  {
    q: "Do I need an appointment for a Japan visa?",
    a: "Yes. Applications must be submitted in person. We handle the file preparation and guide you on the submission process at the Embassy or Consulate/VFS."
  },
  {
    q: "Is there a visa fee for Japan?",
    a: "The official visa fee is generally waived (free) for Pakistani nationals visiting for tourism. However, you must pay our service charges for file processing and itinerary creation."
  },
  {
    q: "How long does the Japan visa take?",
    a: "Once submitted, the processing time is very fast, typically 5 to 7 working days. However, preparing the file with a correct itinerary takes time, so apply early."
  }
];

// --- Japan-Specific Reviews ---
const reviews = [
  {
    name: "Sami J.",
    quote: "The Japan visa requires a very detailed itinerary. O.S. Travel made a perfect day-by-day plan for me. I submitted the file and got my visa in a week!",
    rating: 5
  },
  {
    name: "Ahtisham H.",
    quote: "I was confused about the photo size (it's different for Japan). The team guided me on everything. Excellent file processing service.",
    rating: 5
  },
  {
    name: "Nasir Islam",
    quote: "Trustable service. I got my Japan business visa with their help. They prepared the invitation letter and company docs perfectly.",
    rating: 5
  }
];

// --- Framer Motion Variants ---
const pageVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.5,
      staggerChildren: 0.1
    }
  }
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.5 } }
};

// --- Main Component ---
function Japan() {
  return (
    <motion.div
      className="container mx-auto p-4 md:p-10 bg-gray-50 min-h-screen"
      variants={pageVariants}
      initial="hidden"
      animate="visible"
    >
      {/* 1. Page Header */}
      <motion.div variants={itemVariants} className="flex items-center gap-4 mb-8">
        <img
          src="https://flagcdn.com/w160/jp.png" // Japan flag
          alt="Flag of Japan"
          className="w-16 h-10 object-cover rounded shadow-md"
        />
        <div>
          <h1 className="text-4xl md:text-5xl font-extrabold text-gray-800">
            Japan Visa
          </h1>
          <p className="text-xl text-gray-600">
            Visa File Processing for Pakistani Citizens
          </p>
        </div>
      </motion.div>

      {/* Apply Now Button */}
      <motion.div
        variants={itemVariants}
        className="mt-8 text-center"
      >
        <button
          onClick={() => {
            sessionStorage.setItem('selected_visa_country', 'japan');
            window.location.href = '/apply-visa';
          }}
          className="inline-flex items-center gap-3 px-12 py-5 bg-gradient-to-r from-emerald-600 to-emerald-700 text-white text-xl font-black rounded-2xl shadow-2xl hover:shadow-emerald-500/50 hover:scale-105 transition-all duration-300"
        >
          <FaPassport className="text-2xl" />
          Apply for Japan Visa Now
          <span className="text-2xl">→</span>
        </button>
        <p className="text-sm text-gray-500 mt-4">
          Complete your application in minutes
        </p>
      </motion.div>

      {/* 2. Visa Card Section (File Processing) */}
      <motion.div
        variants={itemVariants}
        className="grid grid-cols-1"
      >
        <FileProcessingCard visa={processingService} />
      </motion.div>

      {/* 3. Embassy & Consulate Information */}
      <motion.div
        variants={itemVariants}
        className="mt-12 grid grid-cols-1 md:grid-cols-2 gap-8"
      >
        <EmbassyCard info={embassyInfo} />
        <EmbassyCard info={consulateInfo} />
      </motion.div>

      {/* 4. About O.S. Travel Section (Highlighting File Processing) */}
      <motion.div
        variants={itemVariants}
        className="mt-12 bg-white p-6 md:p-8 rounded-lg shadow-lg"
      >
        <h2 className="text-3xl font-bold text-gray-800 mb-6 text-center">
          Why Choose O.S. Travel for Your <span className="text-blue-600">Japan Visa</span>?
        </h2>
        <p className="text-lg text-gray-600 text-center mb-8 max-w-3xl mx-auto">
          The Japan visa application requires precision, especially with the travel itinerary.
          <strong className="text-gray-800"> We deal in complete visa file processing</strong> to ensure your application meets the strict standards of the Japanese Embassy.
        </p>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <ServiceCard
            icon={<FaFileSignature className="text-blue-500" />}
            title="Detailed Itinerary"
            desc="We create the mandatory, detailed day-by-day travel plan required by the Embassy."
          />
          <ServiceCard
            icon={<FaCalendarCheck className="text-purple-500" />}
            title="Submission Guidance"
            desc="We guide you on where and how to submit your file (Embassy vs. Consulate/VFS)."
          />
          <ServiceCard
            icon={<FaPlane className="text-green-500" />}
            title="Flight & Hotel Bookings"
            desc="We provide confirmed flight reservations and hotel bookings for your application."
          />
          <ServiceCard
            icon={<FaPassport className="text-yellow-500" />}
            title="Complete File Prep"
            desc="We organize your bank statements, FRC, and photos into a professional visa file."
          />
        </div>
      </motion.div>

      {/* 5. FAQ Section (The "Dropbox") */}
      <motion.div
        variants={itemVariants}
        className="mt-12 bg-white rounded-lg shadow-lg overflow-hidden"
      >
        <h2 className="text-3xl font-bold text-gray-800 p-6 md:p-8">
          Frequently Asked Questions
        </h2>
        <div className="border-t border-gray-200">
          {faqs.map((faq, index) => (
            <AccordionItem key={index} q={faq.q} a={faq.a} />
          ))}
        </div>
      </motion.div>

      {/* 6. Review Section */}
      <motion.div
        variants={itemVariants}
        className="mt-12"
      >
        <h2 className="text-3xl font-bold text-gray-800 mb-8 text-center">
          What Our Clients Say
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {reviews.map((review, index) => (
            <ReviewCard key={index} review={review} />
          ))}
        </div>
      </motion.div>



      {/* Footer Note */}
      <motion.div variants={itemVariants} className="text-center mt-10 text-sm text-gray-500">
        <p>Visa approval is at the sole discretion of the Embassy of Japan. O.S. Travel & Tours provides expert file preparation services.</p>
      </motion.div>

    </motion.div>
  );
}

// --- Reusable Sub-components ---

/**
 * A card component to display details for the File Processing service.
 */
const FileProcessingCard = ({ visa }) => {
  return (
    <div className={`bg-white rounded-lg shadow-xl overflow-hidden border-t-8 border-blue-600`}>
      <div className="p-6 md:p-8">

        {/* Card Header */}
        <div className="flex items-center gap-3 mb-4">
          <div className={`text-4xl text-blue-600`}><FaFileSignature /></div>
          <div>
            <h2 className="text-3xl font-bold text-gray-800">{visa.title}</h2>
            <p className="text-lg text-gray-500">{visa.subtitle}</p>
          </div>
        </div>

        {/* Details Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 gap-y-6 gap-x-4 mb-6 pt-4 border-t border-gray-100">
          <DetailItem icon={<FaMoneyBillWave className="text-green-600" />} label="Service Charges" value={visa.totalFee} />
          <DetailItem icon={<FaClock className="text-red-600" />} label="Processing Time" value={visa.processingTime} />
          <DetailItem icon={<FaCalendarAlt className="text-blue-600" />} label="Validity" value={visa.validity} />
        </div>

        {/* Services Included */}
        <h3 className="text-2xl font-semibold text-gray-800 mb-4 flex items-center gap-2">
          <FaCheckCircle className="text-gray-600" />
          Our Service Package Includes
        </h3>
        <ul className="space-y-3 mb-6 grid grid-cols-1 md:grid-cols-2 gap-x-6">
          {visa.serviceIncludes.map((doc, index) => (
            <li key={index} className="flex items-start gap-3 text-gray-700">
              <FaCheckCircle className="text-blue-500 mt-1.5 shrink-0" />
              <span>{doc}</span>
            </li>
          ))}
        </ul>

        {/* Documents List */}
        <h3 className="text-2xl font-semibold text-gray-800 mb-4 flex items-center gap-2">
          <FaFileAlt className="text-gray-600" />
          Documents Required From You
        </h3>
        <ul className="space-y-3 mb-6 grid grid-cols-1 md:grid-cols-2 gap-x-6">
          {visa.documents.map((doc, index) => (
            <li key={index} className="flex items-start gap-3 text-gray-700">
              <FaCheckCircle className="text-green-500 mt-1.5 shrink-0" />
              <span>{doc}</span>
            </li>
          ))}
        </ul>

        {/* Note */}
        {visa.note && (
          <div className={`p-4 bg-yellow-50 border-l-4 border-yellow-400 text-yellow-800`}>
            <div className="flex items-center gap-3">
              <FaExclamationTriangle className="text-xl shrink-0" />
              <p className="font-semibold">{visa.note}</p>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};

/**
 * A card for Embassy/Consulate info.
 */
const EmbassyCard = ({ info }) => (
  <div className="bg-white p-6 md:p-8 rounded-lg shadow-lg flex flex-col">
    <h2 className="text-2xl font-bold text-gray-800 mb-5 flex items-center gap-3">
      <FaBuilding className={info.title.includes("Embassy") ? "text-red-700" : "text-blue-700"} />
      {info.title}
    </h2>
    <ul className="space-y-4 text-gray-700 text-lg grow">
      <li className="flex items-start gap-4">
        <FaBuilding className="text-gray-500 mt-1.5 shrink-0" />
        <span><strong>Address:</strong> {info.address}</span>
      </li>
      <li className="flex items-start gap-4">
        <FaPhone className="text-gray-500 mt-1.5 shrink-0" />
        <span><strong>Phone:</strong> <a href={`tel:${info.phone.split(' / ')[0]}`} className="text-blue-600 hover:underline">{info.phone}</a></span>
      </li>
      <li className="flex items-start gap-4">
        <FaEnvelope className="text-gray-500 mt-1.5 shrink-0" />
        <span><strong>Email:</strong> <a href={`mailto:${info.email}`} className="text-blue-600 hover:underline">{info.email}</a></span>
      </li>
    </ul>
    <div className="mt-6 p-4 bg-gray-100 border-l-4 border-gray-400 text-gray-800">
      <div className="flex items-center gap-3">
        <FaExclamationTriangle className="text-xl shrink-0" />
        <p className="font-semibold text-sm">{info.note}</p>
      </div>
    </div>
  </div>
);

/**
 * A small component for displaying an icon, label, and value.
 */
const DetailItem = ({ icon, label, value }) => (
  <div className="flex items-start gap-3">
    <div className="text-2xl text-gray-600 mt-1 shrink-0">{icon}</div>
    <div>
      <p className="text-sm font-semibold text-gray-500">{label}</p>
      <p className="text-lg font-bold text-gray-800">{value}</p>
    </div>
  </div>
);

/**
 * An animated Accordion item for the FAQ section.
 */
const AccordionItem = ({ q, a }) => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="border-b border-gray-200">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex justify-between items-center w-full p-6 text-left"
      >
        <span className="text-lg font-semibold text-gray-800">{q}</span>
        <motion.div
          animate={{ rotate: isOpen ? 180 : 0 }}
          transition={{ duration: 0.3 }}
          className="text-gray-500"
        >
          <FaChevronDown className="shrink-0" />
        </motion.div>
      </button>
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1, paddingTop: '0px', paddingBottom: '24px' }}
            exit={{ height: 0, opacity: 0, paddingTop: '0px', paddingBottom: '0px' }}
            transition={{ duration: 0.3, ease: 'easeInOut' }}
            className="overflow-hidden"
          >
            <p className="text-gray-600 px-6">{a}</p>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

// --- Service Card Component ---
const ServiceCard = ({ icon, title, desc }) => (
  <div className="bg-gray-50 border border-gray-200 p-6 rounded-lg text-center flex flex-col items-center">
    <div className="text-4xl mb-4">{icon}</div>
    <h3 className="text-xl font-bold text-gray-800 mb-2">{title}</h3>
    <p className="text-gray-600">{desc}</p>
  </div>
);

// --- Review Card Component ---
const ReviewCard = ({ review }) => (
  <div className="bg-white p-6 rounded-lg shadow-lg flex flex-col">
    <FaQuoteLeft className="text-3xl text-blue-500 mb-4" />
    <p className="text-gray-600 italic mb-6 grow">"{review.quote}"</p>
    <div className="flex items-center justify-between">
      <span className="text-lg font-semibold text-gray-800">{review.name}</span>
      <div className="flex">
        {[...Array(review.rating)].map((_, i) => (
          <FaStar key={i} className="text-yellow-400" />
        ))}
      </div>
    </div>
  </div>
);

export default Japan;